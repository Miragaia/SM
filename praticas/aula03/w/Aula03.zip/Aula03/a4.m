N=3;
A1=A2=A3=1;
f1=10;
f2=20;
f3=30;

fase = rand(1,3)*2*pi -pi
x=sin(10*2*pi*ts+)