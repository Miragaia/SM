function potencia = potencia(Ta,T,x)

n= T/Ta;
p=x(1:n)'*(1:n)/n;

end